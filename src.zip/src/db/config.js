export const DB_CONFIG = {
    apiKey: "AIzaSyD6ZXLgSDyclPBHFUiDorCRPGYuEYRq08s",
    authDomain: "stockhealth-caa9d.firebaseapp.com",
    databaseURL: "https://stockhealth-caa9d.firebaseio.com",
    projectId: "stockhealth-caa9d",
    storageBucket: "stockhealth-caa9d.appspot.com",
    messagingSenderId: "240686697073"
  };


// export const DB_CONFIG = {
//     apiKey: "AIzaSyD6ZXLgSDyclPBHFUiDorCRPGYuEYRq08s",
//     authDomain: "stockhealth-caa9d.firebaseapp.com",
//     databaseURL: "https://stockhealth-caa9d.firebaseio.com",
//     projectId: "stockhealth-caa9d",
//     storageBucket: "stockhealth-caa9d.appspot.com",
//     messagingSenderId: "240686697073"
// }

